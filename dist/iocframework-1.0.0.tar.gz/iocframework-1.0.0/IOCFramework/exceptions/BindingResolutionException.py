class BindingResolutionException(Exception):
    pass
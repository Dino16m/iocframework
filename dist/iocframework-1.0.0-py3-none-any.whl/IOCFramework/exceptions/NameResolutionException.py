class NameResolutionException(Exception):
    pass